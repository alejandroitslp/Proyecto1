

<?php $__env->startSection('title',''.$producto->nombre_producto); ?>

<?php $__env->startSection('content'); ?>
<h1>Codigo de producto: <?php echo e($producto->cod_producto); ?></h1>
<h1><strong> nombre del producto es: </strong><?php echo e($producto->nombre_producto); ?></h1>
<h1>Descripcion: <?php echo e($producto->descripcion_producto); ?></h1>
<h2>Precio de Venta: $ <?php echo e($producto->precio_producto); ?></h2>
<h2>Existencia de producto: <?php echo e($producto->stock_producto); ?></h2>
<p><a href="<?php echo e(route('productos.index')); ?>"> Volver a Productos </a></p><br>
<p><a href="<?php echo e(route('productos.edit', $producto)); ?>">Editar</a></p>

<form action="<?php echo e(route('productos.destroy', $producto)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    <button type="submit">Eliminar</button>
</form>
<h2></h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/Productos/show.blade.php ENDPATH**/ ?>