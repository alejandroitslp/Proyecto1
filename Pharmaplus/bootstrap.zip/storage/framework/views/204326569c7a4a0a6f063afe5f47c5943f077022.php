

<?php $__env->startSection('title','Contactanos'); ?>

<?php $__env->startSection('content'); ?>
<h1>Comunicate con nosotros!</h1>
<form action="<?php echo e(route('contactanos.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <label>Nombre: 
        <br>
        <input type="text" name="nombre">
    </label>
    <br>

    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p><strong><?php echo e($message); ?></strong></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label>Correo:
        <br>
        <input type="text" name="email">
    </label>
    <br>

    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p><strong><?php echo e($message); ?></strong></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label>Mensaje: 
        <br>
        <textarea name="mensaje" rows="4"></textarea>
    </label>
    <br>

    <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p><strong><?php echo e($message); ?></strong></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <button type="submit">Enviar mensaje</button>
</form>
<?php if(session('info')): ?>
    <script>alert("<?php echo e(session('info')); ?>")</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/contactanos/index.blade.php ENDPATH**/ ?>