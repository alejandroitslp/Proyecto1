

<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

<?php
    $color = 'indigo';
?>

<h1>Pagina del Home</h1>
<div class="container mx-auto">
    <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, ['color' => $color]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
         <?php $__env->slot('title'); ?> 
            Titulo1
         <?php $__env->endSlot(); ?>
        Aprovecha las ofertas unicas en nuestro sitio web
     <?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/Home.blade.php ENDPATH**/ ?>