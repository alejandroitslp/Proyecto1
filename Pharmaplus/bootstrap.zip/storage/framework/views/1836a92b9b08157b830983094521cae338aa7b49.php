

<?php $__env->startSection('title','Nosotros'); ?>

<?php $__env->startSection('content'); ?>
<h1>Nosotros</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/nosotros.blade.php ENDPATH**/ ?>