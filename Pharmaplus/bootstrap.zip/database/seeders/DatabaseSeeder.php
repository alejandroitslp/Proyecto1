<?php

namespace Database\Seeders;

use App\Models\Producto;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        /* $varSeed= new Producto();
        $varSeed->cod_usuario="2";
        $varSeed->rut_usuario="14180811";
        $varSeed->login="alejandro";
        $varSeed->password="mephisto696";
        $varSeed->estado="activo";
        $varSeed->acceso="Administrador";
        $varSeed->save(); */
    }
}
