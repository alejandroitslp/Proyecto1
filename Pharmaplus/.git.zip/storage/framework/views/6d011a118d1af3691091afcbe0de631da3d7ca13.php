<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <form action="<?php echo e(route('productos.store')); ?>" method="POST">

                    <?php echo csrf_field(); ?>
            
                    <label>
                        Codigo de producto: 
                        <br>
                        <div class="ml-8 mt-3">
                        <input type="text" name="codigo" value=<?php echo e(old('codigo')); ?> >
                        </div>
                    </label>
            
                    <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                            <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
                    <br>
                    <label>
                         Nombre:
                         <br>
                         <div class="ml-8 mt-3">
                         <input type="text" name="name" value=<?php echo e(old('name')); ?>> 
                         </div>
                    </label>
            
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                            <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
                    <br>
                    <label>
                        Descripcion:
                        <br> 
                        <div class="ml-8 mt-3">
                        <textarea name="descripcion" rows="5"><?php echo e(old('descripcion')); ?></textarea>
                        </div>
                    </label>
            
                    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                            <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
                    <br>
                    <label>
                        Unidad de Producto:
                        <br>
                        <div class="ml-8 mt-3">
                        <input type="text" name="unidad" placeholder="Unidad" value="Unidad" readonly> 
                        </div>
                    </label>
                    <br>
                    <label>
                        Precio de Venta:
                        <br>
                        <div class="ml-8 mt-3">
                        <input type="text" name="precioVenta" value=<?php echo e(old('precioVenta')); ?>>
                        </div>
                    </label>
            
                    <?php $__errorArgs = ['precioVenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                            <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
                    <br>
                    <label>
                        Precio de compra:
                        <br>
                        <div class="ml-8 mt-3">
                        <input type="text" name="precioCompra" value=<?php echo e(old('precioCompra')); ?>>
                        </div>
                    </label>
            
                    <?php $__errorArgs = ['precioCompra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                            <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
                    <br>
                    <label>
                        Stock: 
                        <br>
                        <div class="ml-8 mt-3">
                        <input type="text" name="stock" value=<?php echo e(old('stock')); ?>>
                        </div>
                    </label>
            
                    <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br>
                            <small>*<?php echo e($message); ?></small>
                        <br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
                    <br>
                    <label>
                        Categoria: 
                        <br>
                        <div class="ml-8 mt-3">
                        <input type="text" name="categoria" value="1" readonly placeholder="1 - Farmacia">
                        </div>
                    </label>
                    <br>
                    <div class="ml-8 mt-2">
                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-8"> Enviar formulario</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/Productos/create2.blade.php ENDPATH**/ ?>