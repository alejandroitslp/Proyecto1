<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg ml-8">
                <h1>Codigo de producto: <?php echo e($producto->cod_producto); ?></h1>
                <h1> nombre del producto es: <strong><?php echo e($producto->nombre_producto); ?></strong></h1>
                <h1>Descripcion: <?php echo e($producto->descripcion_producto); ?></h1>
                <h2>Precio de Venta: $ <?php echo e($producto->precio_producto); ?></h2>
                <h2>Existencia de producto: <?php echo e($producto->stock_producto); ?></h2>
                <p><a href="<?php echo e(route('productos.index')); ?>"> Volver a Productos </a></p><br>
                <p><a href="<?php echo e(route('productos.edit', $producto)); ?>" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-6 rounded ml-6 mt-2 ">Editar</a></p>

                <form action="<?php echo e(route('productos.destroy', $producto)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>

                    <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ml-6 mt-2">Eliminar</button>
               
                </form>

            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/Productos/show2.blade.php ENDPATH**/ ?>