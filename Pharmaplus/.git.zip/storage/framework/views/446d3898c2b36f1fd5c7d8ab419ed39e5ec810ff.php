

<?php $__env->startSection('title','Editar Producto'); ?>

<?php $__env->startSection('content'); ?>
<h1>Pagina para editar Producto</h1>
    <form action="<?php echo e(route('productos.update', $producto)); ?>" method="POST">

        <?php echo csrf_field(); ?>

        <?php echo method_field('put'); ?>

        <label>
            Codigo de producto: 
            <br>
            <input type="text" name="codigo" value="<?php echo e(old('codigo',$producto->cod_producto)); ?>">
        </label>

        <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
                <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <br>
        <label>
             Nombre:
             <br>
             <input type="text" name="name" value="<?php echo e(old('name',$producto->nombre_producto)); ?>"> 
        </label>

        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
                <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <br>
        <label>
            Descripcion:
            <br> 
            <textarea name="descripcion" rows="5"><?php echo e(old('descripcion',$producto->descripcion_producto)); ?></textarea>
        </label>

        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
                <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <br>
        <label>
            Unidad de Producto:
            <input type="text" name="unidad" placeholder="Unidad" value="Unidad" readonly> 
        </label>
        <br>
        <label>
            Precio de Venta:
            <br>
            <input type="text" name="precioVenta" value="<?php echo e(old('precioVenta',$producto->precio_producto)); ?>">
        </label>

        <?php $__errorArgs = ['precioVenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
                <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <br>
        <label>
            Precio de compra:
            <input type="text" name="precioCompra" value="<?php echo e(old('precioCompra',$producto->precio_compra)); ?>">
        </label>

        <?php $__errorArgs = ['precioCompra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
                <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <br>
        <label>
            Stock: 
            <br>
            <input type="text" name="stock" value="<?php echo e(old('stock',$producto->stock_producto)); ?>">
        </label>

        <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
                <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <br>
        <label>
            Categoria: 
            <input type="text" name="categoria" value="1" readonly placeholder="1 - Farmacia">
        </label>
        <br>
        <button type="submit"> Actualizar formulario</button>
    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/Productos/edit.blade.php ENDPATH**/ ?>