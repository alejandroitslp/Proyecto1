<footer>
    Este es el pie de pagina
</footer><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>