

<div class="bg-gray-200 bg-opacity-25 grid grid-cols-1 md:grid-cols-1">
    <div class="p-6">
        <div class="flex items-center">
            <div class="ml-4 text-lg text-gray-600 leading-7 font-semibold">Principal</div>
        </div>

        <div class="ml-12">
            <div class="mt-2 text-sm text-gray-500">
                Actualmente sin cambios en Dashboard
            </div>

            
        </div>
    </div>
</div>
<?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/vendor/jetstream/components/welcome.blade.php ENDPATH**/ ?>