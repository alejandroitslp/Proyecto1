<footer>
    Este es el pie de pagina
</footer>