<header>
    <div class="relative items-top justify-center bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">
        <?php if(Route::has('login')): ?>
            <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-gray-700 underline">Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline">Log in</a>

                    <?php if(Route::has('register')): ?>
                        
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <nav>
            <ul>
                <li><a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Home</a>
                </li>
                <li><a href="<?php echo e(route('productos.index')); ?>" class="<?php echo e(request()->routeIs('productos.*') ? 'active' : ''); ?>">Productos</a>
                </li>
                <li><a href="<?php echo e(route('nosotros')); ?>" class="<?php echo e(request()->routeIs('nosotros') ? 'active' : ''); ?>">Nosotros</a>
                </li>
    
                <li>
                    <a href="<?php echo e(route('contactanos.index')); ?>" class="<?php echo e(request()->routeIs('contactanos.*') ? 'active' : ''); ?>">Contactanos</a>
                </li>
            </ul>
        </nav>

    </div>
    
</header><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>