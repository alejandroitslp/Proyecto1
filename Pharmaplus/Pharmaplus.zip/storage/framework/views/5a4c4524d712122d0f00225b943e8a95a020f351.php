

<?php $__env->startSection('title','Index'); ?>

<?php $__env->startSection('content'); ?>
<h1>Pagina de Producto</h1>
<a href="<?php echo e(route('productos.create')); ?>">Crear Producto</a>
<ol>
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

       <li><a href="<?php echo e(route('productos.show',$producto->cod_producto)); ?>"><?php echo e($producto->nombre_producto); ?></a></li> 
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>
<?php echo e($product->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lesin\Desktop\Laravel Tutorial\Proyecto1\Pharmaplus\resources\views/Productos/index.blade.php ENDPATH**/ ?>